package com.example.Estore.Estore.Services;

import com.example.Estore.Estore.Shared.dto.Product.ProductDto;
import com.example.Estore.Estore.Shared.dto.User.UserDto;

public interface ProductService {
    ProductDto createProduct(ProductDto product);


    }



