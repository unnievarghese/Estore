package com.example.Estore.Estore.Ui.Controller;

import com.example.Estore.Estore.Services.CartService;
import com.example.Estore.Estore.Services.UserService;
import com.example.Estore.Estore.Shared.dto.User.UserDto;
import com.example.Estore.Estore.Ui.Model.Response.CartRequest.CartItemRest;
import com.example.Estore.Estore.io.Entity.Cart.CartItemEntity;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/cart")
public class CartController {
    @Autowired
    CartService cartService;
    @Autowired
    UserService userService;
    @PutMapping(path = "/add/{productId}")
    public CartItemRest addCartItem(@PathVariable(value = "productId") String productId,
                                                @RequestParam(value = "quantity") Integer quantity) throws Exception {
        if (productId == null || !(quantity>0)){
            throw new Exception("product is null");
        }
        else {
            Authentication auth = SecurityContextHolder.getContext().getAuthentication();
            UserDto user = userService.getUser(auth.getName());
            CartItemEntity cartItemEntity = cartService.addCartItem(user.getUserId(), productId, quantity);
            return new ModelMapper().map(cartItemEntity,CartItemRest.class);
        }
    }


}
