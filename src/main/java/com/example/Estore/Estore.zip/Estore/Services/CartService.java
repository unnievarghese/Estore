package com.example.Estore.Estore.Services;

import com.example.Estore.Estore.io.Entity.Cart.CartItemEntity;
import com.example.Estore.Estore.io.Entity.Product.ProductEntity;
import com.example.Estore.Estore.io.Entity.User.UserEntity;
import com.example.Estore.Estore.io.Repositories.Cart.CartItemRepository;
import com.example.Estore.Estore.io.Repositories.Product.ProductRepository;
import com.example.Estore.Estore.io.Repositories.User.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


@Service
public class CartService {
    @Autowired
    UserRepository userRepository;
    @Autowired
    ProductRepository productRepository;
    @Autowired
    CartItemRepository cartItemRepository;

    public CartItemEntity addCartItem(String userId, String productId, Integer quantity) {
        UserEntity userEntity=userRepository.findByUserId(userId);
        ProductEntity productEntity=productRepository.findByProductId(productId);

        CartItemEntity cartItemEntity = new CartItemEntity();

        cartItemEntity.setProductEntity(productEntity);
        System.out.println(productEntity.getProductName());
        cartItemEntity.setTotalPrice(productEntity.getPrice()*quantity);
        cartItemEntity.setCartItemId("testId");
        cartItemEntity.setQuantity(quantity);
         cartItemRepository.save(cartItemEntity);


return  cartItemEntity;
    }}