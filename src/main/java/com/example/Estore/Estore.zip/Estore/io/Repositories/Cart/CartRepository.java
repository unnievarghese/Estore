//package com.example.Estore.Estore.io.Repositories.Cart;
//
//import com.example.Estore.Estore.io.Entity.Cart.CartEntity;
//import org.springframework.data.jpa.repository.JpaRepository;
//import org.springframework.data.jpa.repository.Query;
//import org.springframework.stereotype.Repository;
//
//import java.util.List;
//import java.util.Optional;
//
//@Repository
//public interface CartRepository extends JpaRepository<CartEntity,Long> {
//
//    @Query(value = "select * from cart c where c.user_id = ?1 and  c.cart_status=?2",nativeQuery = true)
//    CartEntity getCartByUserId(String userId,String status);
//
//    @Query(value = "select * from cart c where c.user_id = ?1 and c.cart_status = ?2",nativeQuery = true)
//    List<CartEntity> findByUserIdAndStatus(String userId, String status);
//
//    @Query(value = "select * from cart c where c.user_id = ?1 and c.cart_status = ?2",nativeQuery = true)
//    Optional<CartEntity> findByUserId(String userId,String status);
//
//    @Query(value = "select * from cart c where c.user_id=?1 and c.cart_status=?2 ",nativeQuery = true)
//    Optional<CartEntity> findCartById(String userId,String status);
//}
